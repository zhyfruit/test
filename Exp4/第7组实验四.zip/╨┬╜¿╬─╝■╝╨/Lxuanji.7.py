import random
xjgrid = '''琴清流楚激弦商秦曲发声悲摧藏音和咏思惟空堂心忧增慕怀惨伤仁
芳廊东步阶西游王姿淑窈窕伯邵南周风兴自后妃荒经离所怀叹嗟智
兰休桃林阴翳桑怀归思广河女卫郑楚樊厉节中闱淫遐旷路伤中情怀
凋翔飞燕巢双鸠土迤逶路遐志咏歌长叹不能奋飞妄清帏房君无家德
茂流泉清水激扬眷颀其人硕兴齐商双发歌我衮衣想华饰容朗镜明圣
熙长君思悲好仇旧蕤葳桀翠荣曜流华观冶容为谁感英曜珠光纷葩虞
阳愁叹发容摧伤乡悲情我感伤情征宫羽同声相追所多思感谁为荣唐
春方殊离仁君荣身苦惟艰生患多殷忧缠情将如何钦苍穹誓终笃志贞
墙禽心滨均深身加怀忧是婴藻文繁虎龙宁自感思岑形荧城荣明庭妙
面伯改汉物日我兼思何漫漫荣曜华雕旌孜孜伤情幽未犹倾苟难闱显
殊在者之品润乎愁苦艰是丁丽壮观饰容侧君在时岩在炎在不受乱华
意诚惑步育浸集悴我生何冤充颜曜绣衣梦想劳形峻慎盛戒义消作重
感故昵飘施愆殃少章时桑诗端无终始诗仁颜贞寒嵯深兴后姬源人荣
故遗亲飘生思愆精徽盛医风比平始璇情贤丧物岁峨虑渐孽班祸谗章
新旧闻离天罪辜神恨昭盛兴作苏心玑明别改知识深微至嬖女因奸臣
霜废远微地积何遐微业孟鹿丽氏诗图显行华终凋渊察大赵婕所佞贤
水故离隔德怨因幽元倾宣鸣辞理兴义怨士容始松重远伐氏好恃凶惟
齐君殊乔贵其备旷悼思伤怀日往感年衰念是旧愆涯祸用飞辞恣害圣
杰子我木平根当远叹水感悲思忧远劳情谁为独居经在昭燕辇极我配
志惟同谁均难苦离戚戚情哀慕岁殊叹时贱女怀欢网防青实汉骄忠英
清新衾阴匀寻辛凤知我者谁世异浮寄倾鄙贱何如罗萌青生成盈贞皇
纯贞志一专所当麟沙流颓逝异浮沉华英翳曜潜阳林西昭景薄榆桑伦
望微精感通明神龙驰若然倏逝惟时年殊白日西移光滋愚谗漫顽凶匹
谁云浮寄身轻飞昭亏不盈无倏必盛有衰无日不陂流蒙谦退休孝慈离
思辉光饬桀殊文德离忠体一达心意志殊愤激何施电疑危远家和雍飘
想群离散妾孤遗怀仪容仰俯荣华丽饰身将无谁为逝容节敦贞淑思浮
怀悲哀声殊乖分圣赀何情忧感惟哀志节上通神祇推持所贞记自恭江
所春伤应翔雁归皇辞成者作体下遗葑菲采者无差生从是敬孝为基湘
亲刚柔有女为贱人房幽处己悯微身长路悲旷感生民梁山殊塞隔河津'''

grid = xjgrid.split('\n')
dx = [0, 0 , 1 , 1 ,1,-1,-1,-1]
dy = [1, -1, 1, -1, 0, 0, 1, -1]


redpool = [(i, j) for i in [0, 7, 14, 22, 28] for j in [0,7,14, 22,28]]
def getsentence(x, y, d):
    ret = ''
    for i in range(7):
        ret += grid[x][y]
        x += dx[d]
        y += dy[d]
    return (ret, x, y)
astpos = [(0, 0), (0, 28), (0, 7), (0, 22)]
for ax, ay in astpos:
    ans_a = ''
    for i in range(4):
        tmp, ax, ay = getsentence(ax, ay, 4)
        ans_a += tmp + (',' if i != 3 else '。')
    print(ans_a)

circ = [4, 1, 5, 0]
bstpos = [(0, 7), (0, 28), (21, 28), (21, 7)]

for bx, by in bstpos:
    ans_b = ''
    for i in circ:
        tmp, bx, by = getsentence(bx, by, i)
        ans_b += tmp + (',' if i != 0 else '。')
    print(ans_b)
blackpool = [(1,1), (1, 22), (22, 1), (22,22)]
for cx, cy in blackpool:
    ans_c = ''
    for i in range(6):
        if i & 1:
            for j in range(cy, cy + 6):
                ans_c += grid[i + cx][j]
        else:
            for j in range(cy + 5, cy - 1, -1):
                ans_c += grid[i + cx][j] 
        ans_c += '。'
    print(ans_c)
def getrandsentence(x, y, length = 7):
    d = random.choice([0,1,4,5])
    while x + length * dx[d] not in range(0, 29) or y + length * dy[d] not in range(0, 29):    
        x, y = random.choice(redpool)
    ret = ''
    for i in range(length):
        x += dx[d]
        y += dy[d]
        ret += grid[x][y]
    return ret, x, y
def getrandseven():
    memx, memy = random.choice(redpool)
    mems = set()
    ans = ''
    for i in range(4):
        tmp, memx, memy = getrandsentence(memx, memy)
        while tmp in mems:
            tmp, memx, memy = getrandsentence(memx, memy)
        mems.add(tmp)
        ans += tmp + (',' if i != 3 else '。')
    return ans
def getrevseven():
    memx, memy = random.choice(redpool)
    mems = set()
    ans = ''
    for i in range(4):
        tmp, memx, memy = getrandsentence(memx, memy)
        mems.add(tmp)
        ans += tmp[::-1] + (',' if i != 3 else '。')
    return ans

for i in range(8):
    print(getrandseven())
    #print(getrevseven())
    